/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lhorefto <lhorefto@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/13 19:49:07 by lhorefto          #+#    #+#             */
/*   Updated: 2021/02/14 15:48:30 by lhorefto         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	ft_putstr_non_printable(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 32 && str[i] > 0)
		{
			ft_putchar('\\');
			if (str[i] < 16 && str[i] > 0)
				ft_putchar('0');
			else
				ft_putchar('1');
			if (str[i] % 16 < 10)
				ft_putchar(str[i] % 16 + '0');
			else
				ft_putchar(str[i] % 16 + 87);
		}
		else
			ft_putchar(str[i]);
		i++;
	}
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
