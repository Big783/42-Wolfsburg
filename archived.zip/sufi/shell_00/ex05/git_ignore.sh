#!/bin/bash
git ls-files . --ignored --exclude-standard --others 
