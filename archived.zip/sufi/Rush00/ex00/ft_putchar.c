/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aricholm <aricholm@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/12 19:14:05 by aricholm          #+#    #+#             */
/*   Updated: 2021/02/14 12:45:05 by aricholm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_makeline(int x, char left, char middle, char right)
{
	int i;

	if (x == 1)
		ft_putchar(left);
	else
	{
		ft_putchar(left);
		i = 0;
		while (i < x - 2)
		{
			ft_putchar(middle);
			i++;
		}
		ft_putchar(right);
	}
	ft_putchar('\n');
}
