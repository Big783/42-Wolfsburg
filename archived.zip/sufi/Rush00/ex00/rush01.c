/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aricholm <aricholm@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/12 19:06:35 by aricholm          #+#    #+#             */
/*   Updated: 2021/02/14 12:59:24 by aricholm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);
void	ft_makeline(int i, char left, char middle, char right);

void	rush(int x, int y)
{
	int			i;
	const char	a = '/';
	const char	b = '*';
	const char	c = '\\';

	i = 0;
	if (x > 0 && y > 0)
	{
		if (y == 1)
		{
			ft_makeline(x, a, b, c);
		}
		else
		{
			ft_makeline(x, a, b, c);
			while (i < y - 2)
			{
				ft_makeline(x, b, ' ', b);
				i++;
			}
			ft_makeline(x, c, b, a);
		}
	}
}
