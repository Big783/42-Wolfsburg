/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   smith.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gerlingi <gerlingi@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 21:23:56 by gerlingi          #+#    #+#             */
/*   Updated: 2021/02/21 21:57:22 by gerlingi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	blue_pill(void)
{
	write(1, "2 4 3 1", 7);
	write(1, "\n", 1);
	write(1, "4 3 1 2", 7);
	write(1, "\n", 1);
	write(1, "3 1 2 4", 7);
	write(1, "\n", 1);
	write(1, "1 2 4 3", 7);
	write(1, "\n", 1);
	return ;
}

void	machines(void)
{
	write(1, "1 2 4 3", 7);
	write(1, "\n", 1);
	write(1, "2 4 3 1", 7);
	write(1, "\n", 1);
	write(1, "4 3 1 2", 7);
	write(1, "\n", 1);
	write(1, "3 1 2 4", 7);
	write(1, "\n", 1);
	return ;
}

void	oracle(void)
{
	write(1, "4 2 3 1", 7);
	write(1, "\n", 1);
	write(1, "2 3 1 4", 7);
	write(1, "\n", 1);
	write(1, "3 1 4 2", 7);
	write(1, "\n", 1);
	write(1, "1 4 2 3", 7);
	write(1, "\n", 1);
	return ;
}

void	architect(void)
{
	write(1, "1 4 2 3", 7);
	write(1, "\n", 1);
	write(1, "4 2 3 1", 7);
	write(1, "\n", 1);
	write(1, "2 3 1 4", 7);
	write(1, "\n", 1);
	write(1, "3 1 4 2", 7);
	write(1, "\n", 1);
	return ;
}

void	keymaker(void)
{
	write(1, "3 1 4 2", 7);
	write(1, "\n", 1);
	write(1, "1 4 2 3", 7);
	write(1, "\n", 1);
	write(1, "4 2 3 1", 7);
	write(1, "\n", 1);
	write(1, "2 3 1 4", 7);
	write(1, "\n", 1);
	return ;
}
