/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   trinity.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gerlingi <gerlingi@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 20:46:56 by gerlingi          #+#    #+#             */
/*   Updated: 2021/02/21 21:19:58 by gerlingi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	trinity(void)
{
	write(1, "2 1 4 3", 7);
	write(1, "\n", 1);
	write(1, "1 4 3 2", 7);
	write(1, "\n", 1);
	write(1, "4 3 2 1", 7);
	write(1, "\n", 1);
	write(1, "3 2 1 4", 7);
	write(1, "\n", 1);
	return ;
}

void	bullet_time(void)
{
	write(1, "4 2 1 3", 7);
	write(1, "\n", 1);
	write(1, "2 1 3 4", 7);
	write(1, "\n", 1);
	write(1, "1 3 4 2", 7);
	write(1, "\n", 1);
	write(1, "3 4 2 1", 7);
	write(1, "\n", 1);
	return ;
}

void	zion(void)
{
	write(1, "3 4 2 1", 7);
	write(1, "\n", 1);
	write(1, "4 2 1 3", 7);
	write(1, "\n", 1);
	write(1, "2 1 3 4", 7);
	write(1, "\n", 1);
	write(1, "1 3 4 2", 7);
	write(1, "\n", 1);
	return ;
}

void	merovingian(void)
{
	write(1, "1 3 4 2", 7);
	write(1, "\n", 1);
	write(1, "3 4 2 1", 7);
	write(1, "\n", 1);
	write(1, "4 2 1 3", 7);
	write(1, "\n", 1);
	write(1, "2 1 3 4", 7);
	write(1, "\n", 1);
	return ;
}

void	agent_smith(void)
{
	write(1, "4 3 1 2", 7);
	write(1, "\n", 1);
	write(1, "3 1 2 4", 7);
	write(1, "\n", 1);
	write(1, "1 2 4 3", 7);
	write(1, "\n", 1);
	write(1, "2 4 3 1", 7);
	write(1, "\n", 1);
	return ;
}
