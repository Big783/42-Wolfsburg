/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   matrixreloaded.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gerlingi <gerlingi@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 21:34:13 by gerlingi          #+#    #+#             */
/*   Updated: 2021/02/21 21:56:43 by gerlingi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	machines();
void	oracle();
void	architect();
void	keymaker();

void	matrix_is_real5(int arr[])
{
	if (arr[1] == 3 && arr[2] == 2 && arr[3] == 1 &&
	arr[4] == 2 && arr[5] == 2 && arr[6] == 3 && arr[7] == 3 && arr[8] == 1
	&& arr[9] == 3 && arr[10] == 2 && arr[11] == 1 && arr[12] == 2
	&& arr[13] == 2 && arr[14] == 3 && arr[15] == 3 && arr[16] == 1)
		machines();
	if (arr[1] == 1 && arr[2] == 3 && arr[3] == 2 &&
	arr[4] == 2 && arr[5] == 3 && arr[6] == 1 && arr[7] == 2 && arr[8] == 2
	&& arr[9] == 1 && arr[10] == 3 && arr[11] == 2 && arr[12] == 2
	&& arr[13] == 3 && arr[14] == 1 && arr[15] == 2 && arr[16] == 2)
		oracle();
	if (arr[1] == 2 && arr[2] == 1 && arr[3] == 3 &&
	arr[4] == 2 && arr[5] == 2 && arr[6] == 3 && arr[7] == 1 && arr[8] == 2
	&& arr[9] == 2 && arr[10] == 1 && arr[11] == 3 && arr[12] == 2
	&& arr[13] == 2 && arr[14] == 3 && arr[15] == 1 && arr[16] == 2)
		architect();
	if (arr[1] == 2 && arr[2] == 2 && arr[3] == 1 &&
	arr[4] == 3 && arr[5] == 2 && arr[6] == 2 && arr[7] == 3 && arr[8] == 1
	&& arr[9] == 2 && arr[10] == 2 && arr[11] == 1 && arr[12] == 3
	&& arr[13] == 2 && arr[14] == 2 && arr[15] == 3 && arr[16] == 1)
		keymaker();
}
