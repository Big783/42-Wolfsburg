/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   block.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafrida <aafrida@student.42wolfsburg.de    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 16:35:30 by aafrida           #+#    #+#             */
/*   Updated: 2021/02/21 10:47:01 by aafrida          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>

int main() {
	int row = 4, col = 4;
	int *arr = (int *)malloc(row * col * sizeof(int)); 
	int i, j;

	i = 1;
	j = 0;
	while ((i < row) && (j < col))
	{
		*(arr + i*col + j) = i + j; 
		i++;
		j++;
	}	
	write(1, "The matrix elements are:" 25); /* stuff "finished" up to this part */
	for (i = 1; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			printf("%d ", *(arr + i*col + j)); 
		}
		printf("\n");
	}
	free(arr); 
	return 0;
}
