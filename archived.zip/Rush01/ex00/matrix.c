/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   matrix.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gerlingi <gerlingi@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 19:28:58 by gerlingi          #+#    #+#             */
/*   Updated: 2021/02/21 22:35:47 by gerlingi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	neo_wake_up();
void	the_matrix_has_you();
void	follow_the_white_rabbit();
void	knock_knock_neo();
void	dejavu();
void	mr_anderson();
void	neo();
void	he_is_the_one();
void	morpheus();
void	red_pill();
void	trinity();
void	bullet_time();
void	zion();
void	merovingian();
void	agent_smith();
void	blue_pill();
void	matrix_is_real5();

void	matrix_is_real4(int arr[])
{
	if (arr[1] == 2 && arr[2] == 1 && arr[3] == 3 &&
	arr[4] == 3 && arr[5] == 3 && arr[6] == 2 && arr[7] == 1 && arr[8] == 2
	&& arr[9] == 2 && arr[10] == 1 && arr[11] == 3 && arr[12] == 3
	&& arr[13] == 3 && arr[14] == 2 && arr[15] == 1 && arr[16] == 2)
		zion();
	if (arr[1] == 3 && arr[2] == 2 && arr[3] == 1 &&
	arr[4] == 3 && arr[5] == 2 && arr[6] == 3 && arr[7] == 2 && arr[8] == 1
	&& arr[9] == 3 && arr[10] == 2 && arr[11] == 1 && arr[12] == 3
	&& arr[13] == 2 && arr[14] == 3 && arr[15] == 2 && arr[16] == 1)
		merovingian();
	if (arr[1] == 1 && arr[2] == 2 && arr[3] == 3 &&
	arr[4] == 2 && arr[5] == 3 && arr[6] == 1 && arr[7] == 2 && arr[8] == 3
	&& arr[9] == 1 && arr[10] == 2 && arr[11] == 3 && arr[12] == 2
	&& arr[13] == 3 && arr[14] == 1 && arr[15] == 2 && arr[16] == 3)
		agent_smith();
	if (arr[1] == 2 && arr[2] == 1 && arr[3] == 2 &&
	arr[4] == 3 && arr[5] == 3 && arr[6] == 3 && arr[7] == 1 && arr[8] == 2
	&& arr[9] == 2 && arr[10] == 1 && arr[11] == 2 && arr[12] == 3
	&& arr[13] == 3 && arr[14] == 3 && arr[15] == 1 && arr[16] == 2)
		blue_pill();
	matrix_is_real5(arr);
}

void	matrix_is_real3(int arr[])
{
	if (arr[1] == 1 && arr[2] == 2 && arr[3] == 2 &&
	arr[4] == 2 && arr[5] == 4 && arr[6] == 1 && arr[7] == 2 && arr[8] == 3
	&& arr[9] == 1 && arr[10] == 2 && arr[11] == 2 && arr[12] == 2
	&& arr[13] == 4 && arr[14] == 1 && arr[15] == 2 && arr[16] == 3)
		morpheus();
	if (arr[1] == 2 && arr[2] == 1 && arr[3] == 2 &&
	arr[4] == 2 && arr[5] == 3 && arr[6] == 4 && arr[7] == 1 && arr[8] == 2
	&& arr[9] == 2 && arr[10] == 1 && arr[11] == 2 && arr[12] == 2
	&& arr[13] == 3 && arr[14] == 4 && arr[15] == 1 && arr[16] == 2)
		red_pill();
	if (arr[1] == 2 && arr[2] == 2 && arr[3] == 1 &&
	arr[4] == 2 && arr[5] == 2 && arr[6] == 3 && arr[7] == 4 && arr[8] == 1
	&& arr[9] == 2 && arr[10] == 2 && arr[11] == 1 && arr[12] == 2
	&& arr[13] == 2 && arr[14] == 3 && arr[15] == 4 && arr[16] == 1)
		trinity();
	if (arr[1] == 1 && arr[2] == 3 && arr[3] == 3 &&
	arr[4] == 2 && arr[5] == 2 && arr[6] == 1 && arr[7] == 2 && arr[8] == 3
	&& arr[9] == 1 && arr[10] == 3 && arr[11] == 3 && arr[12] == 2
	&& arr[13] == 2 && arr[14] == 1 && arr[15] == 2 && arr[16] == 3)
		bullet_time();
	matrix_is_real4(arr);
}

void	matrix_is_real2(int arr[])
{
	if (arr[1] == 2 && arr[2] == 2 && arr[3] == 2 &&
	arr[4] == 1 && arr[5] == 1 && arr[6] == 2 && arr[7] == 3 && arr[8] == 4
	&& arr[9] == 2 && arr[10] == 2 && arr[11] == 2 && arr[12] == 1
	&& arr[13] == 1 && arr[14] == 2 && arr[15] == 3 && arr[16] == 4)
		dejavu();
	if (arr[1] == 3 && arr[2] == 2 && arr[3] == 1 &&
	arr[4] == 4 && arr[5] == 2 && arr[6] == 2 && arr[7] == 2 && arr[8] == 1
	&& arr[9] == 3 && arr[10] == 2 && arr[11] == 1 && arr[12] == 4
	&& arr[13] == 2 && arr[14] == 2 && arr[15] == 2 && arr[16] == 1)
		mr_anderson();
	if (arr[1] == 2 && arr[2] == 1 && arr[3] == 4 &&
	arr[4] == 3 && arr[5] == 2 && arr[6] == 2 && arr[7] == 1 && arr[8] == 2
	&& arr[9] == 2 && arr[10] == 1 && arr[11] == 4 && arr[12] == 3
	&& arr[13] == 2 && arr[14] == 2 && arr[15] == 1 && arr[16] == 2)
		neo();
	if (arr[1] == 1 && arr[2] == 4 && arr[3] == 3 &&
	arr[4] == 2 && arr[5] == 2 && arr[6] == 1 && arr[7] == 2 && arr[8] == 2
	&& arr[9] == 1 && arr[10] == 4 && arr[11] == 3 && arr[12] == 2
	&& arr[13] == 2 && arr[14] == 1 && arr[15] == 2 && arr[16] == 2)
		he_is_the_one();
	matrix_is_real3(arr);
}

void	matrix_is_real(int arr[])
{
	if (arr[1] == 3 && arr[2] == 3 && arr[3] == 2 &&
	arr[4] == 1 && arr[5] == 1 && arr[6] == 2 && arr[7] == 3 && arr[8] == 2
	&& arr[9] == 3 && arr[10] == 3 && arr[11] == 2 && arr[12] == 1
	&& arr[13] == 1 && arr[14] == 2 && arr[15] == 3 && arr[16] == 2)
		neo_wake_up();
	if (arr[1] == 2 && arr[2] == 3 && arr[3] == 2 &&
	arr[4] == 1 && arr[5] == 1 && arr[6] == 2 && arr[7] == 3 && arr[8] == 3
	&& arr[9] == 2 && arr[10] == 3 && arr[11] == 2 && arr[12] == 1
	&& arr[13] == 1 && arr[14] == 2 && arr[15] == 3 && arr[16] == 3)
		the_matrix_has_you();
	if (arr[1] == 3 && arr[2] == 2 && arr[3] == 2 &&
	arr[4] == 1 && arr[5] == 1 && arr[6] == 2 && arr[7] == 2 && arr[8] == 3
	&& arr[9] == 3 && arr[10] == 2 && arr[11] == 2 && arr[12] == 1
	&& arr[13] == 1 && arr[14] == 2 && arr[15] == 2 && arr[16] == 3)
		follow_the_white_rabbit();
	if (arr[1] == 4 && arr[2] == 3 && arr[3] == 2 &&
	arr[4] == 1 && arr[5] == 1 && arr[6] == 2 && arr[7] == 2 && arr[8] == 2
	&& arr[9] == 4 && arr[10] == 3 && arr[11] == 2 && arr[12] == 1
	&& arr[13] == 1 && arr[14] == 2 && arr[15] == 2 && arr[16] == 2)
		knock_knock_neo();
	matrix_is_real2(arr);
}

int		main(int argc, char *argv[])
{
	int i;
	int array_of_ints[32];

	i = 1;
	while (i < argc && i < argc)
	{
		array_of_ints[i] = atoi(argv[i]);
		i++;
	}
	if (i < 17 || i > 17)
	{
		write(1, "Error", 6);
		write(1, "\n", 1);
		return (0);
	}
	matrix_is_real(array_of_ints);
}
