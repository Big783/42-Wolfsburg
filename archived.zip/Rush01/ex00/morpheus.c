/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   morpheus.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gerlingi <gerlingi@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 20:15:16 by gerlingi          #+#    #+#             */
/*   Updated: 2021/02/21 20:53:18 by gerlingi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	mr_anderson(void)
{
	write(1, "2 3 4 1", 7);
	write(1, "\n", 1);
	write(1, "3 4 1 2", 7);
	write(1, "\n", 1);
	write(1, "4 1 2 3", 7);
	write(1, "\n", 1);
	write(1, "1 2 3 4", 7);
	write(1, "\n", 1);
	return ;
}

void	neo(void)
{
	write(1, "3 4 1 2", 7);
	write(1, "\n", 1);
	write(1, "4 1 2 3", 7);
	write(1, "\n", 1);
	write(1, "1 2 3 4", 7);
	write(1, "\n", 1);
	write(1, "2 3 4 1", 7);
	write(1, "\n", 1);
	return ;
}

void	he_is_the_one(void)
{
	write(1, "4 1 2 3", 7);
	write(1, "\n", 1);
	write(1, "1 2 3 4", 7);
	write(1, "\n", 1);
	write(1, "2 3 4 1", 7);
	write(1, "\n", 1);
	write(1, "3 4 1 2", 7);
	write(1, "\n", 1);
	return ;
}

void	morpheus(void)
{
	write(1, "4 3 2 1", 7);
	write(1, "\n", 1);
	write(1, "3 2 1 4", 7);
	write(1, "\n", 1);
	write(1, "2 1 4 3", 7);
	write(1, "\n", 1);
	write(1, "1 4 3 2", 7);
	write(1, "\n", 1);
	return ;
}

void	red_pill(void)
{
	write(1, "1 4 3 2", 7);
	write(1, "\n", 1);
	write(1, "4 3 2 1", 7);
	write(1, "\n", 1);
	write(1, "3 2 1 4", 7);
	write(1, "\n", 1);
	write(1, "2 1 4 3", 7);
	write(1, "\n", 1);
	return ;
}
