/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjurgen <fjurgen@student.42wolfsburg.de    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/22 11:10:50 by fjurgen           #+#    #+#             */
/*   Updated: 2021/02/23 17:42:33 by fjurgen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_strcap_check_letter(char *str, int *change_to_cap)
{
	if ((((*str >= 'a') && (*str <= 'z')) || ((*str >= 'A') &&
	(*str <= 'Z')) || ((*str >= 48) && (*str <= 57))))
	{
		*change_to_cap = 0;
		if ((*str >= 'A') && (*str <= 'Z'))
			*str = *str + 32;
	}
	else
		*change_to_cap = 1;
}

char	*ft_strcapitalize(char *str)
{
	int		i;
	int		change_to_cap;

	change_to_cap = 1;
	i = 0;
	while (*str)
	{
		if (((*str >= 'a') && (*str <= 'z')) && (change_to_cap == 1))
		{
			*str = *str - 32;
			change_to_cap = 0;
		}
		else
		{
			ft_strcap_check_letter(str, &change_to_cap);
		}
		str++;
		i++;
	}
	return (str - i);
}
