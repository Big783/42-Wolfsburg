/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjurgen <fjurgen@student.42wolfsburg.de    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 18:20:18 by fjurgen           #+#    #+#             */
/*   Updated: 2021/02/22 17:31:07 by fjurgen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_str_is_lowercase(char *str)
{
	int	check;

	check = 1;
	while (*str)
	{
		if (!((*str >= 'a') && (*str <= 'z')))
		{
			check = 0;
			break ;
		}
		str++;
	}
	return (check);
}
