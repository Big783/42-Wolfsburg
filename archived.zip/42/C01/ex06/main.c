#include <stdio.h>
#include <string.h>

int	ft_strlen(char *str);

int main(void)
{
	char a[] = "hello";
	printf("%d \n", ft_strlen(a));
}