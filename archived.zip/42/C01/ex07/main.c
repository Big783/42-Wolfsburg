#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size);

int main()
{
	int *tab;
	printf("%d\n", *tab--);
	return(0);
}
