#include <stdio.h>

void	ft_ft(int *nbr);

int main()
{
	int nbr;
	ft_ft(&nbr);
	printf("%i\n", nbr);
}