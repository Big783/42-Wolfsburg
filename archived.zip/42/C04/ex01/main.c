#include <unistd.h>

void	ft_putstr(char *str);

int main()
{
	char str [] = "hello";
	ft_putstr(str);
}