#include <stdio.h>
#include <string.h>

int	ft_strlen(char *str);

int main(void)
{
	char a [] = "I miss you";
	printf("%d \n", ft_strlen(a));
}