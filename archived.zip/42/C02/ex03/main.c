#include <stdio.h>

int	ft_str_is_numeric(char *str);

int main()
{
	char str [] = "";
	printf("%i \n", ft_str_is_numeric(str));
	return (0);
}