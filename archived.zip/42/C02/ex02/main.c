#include <stdio.h>
#include <string.h>

int	ft_str_is_alpha(char *str);

int main()
{
	char str [] = "";
	//ft_str_is_alpha(str);
	printf("%d \n", ft_str_is_alpha(str));
	return (0);
}