#include <stdio.h>
#include <string.h>

int	ft_str_is_lowercase(char *str);

int main()
{
	char str [] = "";
	printf("%d \n", ft_str_is_lowercase(str));
	return (0);
}