#include <unistd.h>
#include <stdio.h>

char    *ft_strcpy(char *dest, char *src);

void    ft_putchar(char c)
{
    write(1, &c, 1);
}

int        main()
{
    char    src[] = "MrScruffKeepMoving";
    char    dest[] = {};

    ft_strcpy(dest, src);
    // ft_putchar(*dest);
    // write(1, dest, 20);
    printf("%s", dest);