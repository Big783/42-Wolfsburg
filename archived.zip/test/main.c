void ft_ft(void);

int main(void)
{
	ft_ft();
}